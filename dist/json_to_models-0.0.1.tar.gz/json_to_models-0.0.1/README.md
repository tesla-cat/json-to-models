# json to models
 
extracts python models from json files

